package org.mobile.framework.pageObjects;
public enum PageObjectsEnum {

    LOGINPAGE,
    HOMEPAGE,

    CustomerPage





}
